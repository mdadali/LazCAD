
An AS3 Flash module written by Ari Arnbj�rnsson < ari@flassari.is >
that wraps the Clipper library can be downloaded from:
https://github.com/Flassari/as3clipper
