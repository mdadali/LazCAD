#ifndef CLIPPER_VERSION_H
#define CLIPPER_VERSION_H

constexpr auto CLIPPER2_VERSION = "1.3.0";

#endif  // CLIPPER_VERSION_H
