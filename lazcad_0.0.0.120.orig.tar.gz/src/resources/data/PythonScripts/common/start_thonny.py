from thonny import launch
launch()