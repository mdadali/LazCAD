
A Matlab wrapper for Clipper by Emmett (emmettl@u.washington.edu) can be downloaded from:

http://www.mathworks.com/matlabcentral/fileexchange/36241